# MergedKline family implementation plan
## 000 — Scope
Implement `MergedKline` and `MergedKlineSeries` from memo009’s feature interfaces,[1] using memo015’s inclusion definitions, algorithm and source contracts.[2] Follow memo013’s baseline/skill comparison process and class-centered interface format.[3] Core calculation, ChanTable/DataFrame integration and plotting are implemented. Section003 describes the current two-class API; confirmation rules and dual-path warning scoring remain deferred.
## 001 — Implementation plan
Reuse memo013’s implemented `Kline`/`KlineTSeries` and `KlineTSeries.read_csv(...)` with its owned `context`, using the existing master/context in `samples/chan_table/`; no new raw-data preparation is needed. Preserve the original files, source labels and volume units. Before execution, record the exact input/configuration/rule version, allowed changes and acceptance checks in a task under `mas/tasks/`.
### 001.a — Implement the MergedKline family
1. Keep the two immutable domain classes in `src/chanlab/algo/merged_kline.py`:8 record members and6 series members, with automatic validation.
2. Retain the exact raw KlineTSeries, configuration, rule version and complete trace. Use result-scoped integer IDs independently of raw/tuple positions.
3. Encapsulate memo015’s sequential inclusion algorithm and six helpers as private MergedKlineSeries methods. The loop owns raw consumption, ID assignment, saving and EOF.
4. Require explicit initialization policy. Preserve UP/DOWN/OUTER behavior and pending/dual data for UNSET/BOTH without introducing more classes or selecting a default.
5. Validate complete source coverage and adjacent noninclusion, including equal boundaries; permit nonadjacent inclusion. Display each result at its first raw member and keep confirmation separate.
6. Add sequence operations, ID lookup and source/rule-grounded explanation, covering decisions that produce no saved record.
7. Expose table registration/retrieval, compact DataFrame export and plotting as class/instance methods. Keep file-format/rendering details in dedicated adapters behind the methods; preserve raw data and existing registrations.
8. Add plotting after core selection and record extension checks separately. Later Chan detectors, confirmation rules, warning scoring and general DecisionStep design remain outside the implemented scope.
### 001.b — Repeat the core implementation using Python Pro
1. Complete the baseline against the agreed core contract and common tests; freeze its source, checks and hashes under `artifacts/mas/merged-kline-family/baseline/` before the continuation.
2. Record the exact invocation request verbatim in the execution task; read `mas/skills/python-pro/SKILL.md` and record its actual source/version.[4]
3. Repeat001.a’s core scope with identical public interfaces, algorithm options, fixtures, dataset and acceptance tests. Preserve the continuation separately under `artifacts/mas/merged-kline-family/python_pro/`.
4. Record prior skill exposure and later corrections. This is the same sequential engineering comparison used in013; do not claim the author has never read the skill or attribute differences solely to it.
### 001.c — Compare and select the core implementation
1. Run both frozen variants against the same final suite in isolated processes; verify which source each process imports. Retain failures and intermediate diagnostics rather than hiding baseline defects.
2. Compare memo009 interface coverage, memo015 rule compliance, source identity/ranges, immutable state, initialization/pending/dual-path handling, trace/explanation, validation errors, typing, readability and dependencies.
3. Save the comparison, actual commands/results and snapshot hashes under `artifacts/mas/merged-kline-family/`. Select shared source with explicit reasons and identify review corrections separately.
4. Run the selected version with the complete existing dataset and each agreed configuration. Report actual raw/result counts and evidence; do not copy013’s historical test counts or infer correctness from a plausible reduction ratio.
### 001.d — Test the MergedKline family
1. **Records and series:** valid construction, automatic validation, invalid numeric/ID/index/direction values, frozen fields, nonempty output, exact source identity, integer/negative indexing, tuple slices, iteration and ID lookup including missing-ID `KeyError`.
2. **Rules:** both containment orientations, strict upward/downward transitions, equal highs/lows, complete equality, one-price bars and repeated inclusion. Reproduce015’s main example, all initialization examples and its sequential-processing counterexample.
3. **Initialization:** apply policy only when needed; check single-bar EOF and initial noninclusion without forced direction/forking. Check UNSET stops without consuming the candidate, OUTER retains None, and BOTH has independent paths with the upward main result. Warning assertions require an agreed metric/threshold.
4. **Source/result invariants:** reject gaps, overlaps, out-of-bounds ranges, incomplete coverage, duplicate IDs and adjacent inclusion. Accept nonadjacent inclusion and a single result. Confirm display placement remains at the first member after every absorption.
5. **Trace/explanation:** trace coverage of no-output branches, one trace-index tuple per result, in-bounds indices and explanations matching the recorded rule/source context. Check status/UTC confirmation against the agreed rules; EOF must not fabricate confirmation.
6. **Full data and preservation:** load the existing master/context through memo013’s loader; calculate without changing raw values, timestamps, metadata, source files or earlier snapshots. Save compact derived records and configuration/source/rule evidence as verification artifacts, not as a newly standardized interchange format.
7. **Quality checks:** run focused tests and the existing regression suite with `.venv/bin/python -m pytest`; run report-only Ruff. Following013’s selected-version checks, record strict mypy, Black check mode and coverage for the changed modules with actual commands and results. Do not edit unrelated files to satisfy tooling.
8. **Plotting:** verify selected intervals, source timestamps, range/ID hover data, optional raw volume, empty selections, missing optional dependency, no source mutation, Figure return and HTML export; inspect representative charts visually. Record this extension separately from the core comparison.
## 002 — Implementation notes and logs
### 002.a — Implement the MergedKline family → 001.a
The current [algorithm module](../../src/chanlab/algo/merged_kline.py) implements exactly two classes, source-aware sequential inclusion, immutable configuration/evidence data and private calculation helpers. The series provides validation, access, ID lookup, explanation, table/DataFrame conversion and plotting. Current interfaces and examples are in003.
### 002.b — Apply Python Pro → 001.b
The original baseline passed23 acceptance cases before freezing. Python Pro1.1.0 was then applied as a sequential typed continuation, improving trace validation, typing and documentation. [The execution task](../../mas/tasks/20261109-memo026-execution.md) records the exact invocation. [Baseline](../../artifacts/mas/merged-kline-family/baseline/) and [continuation](../../artifacts/mas/merged-kline-family/python_pro/) are preserved historical snapshots; the current two-class correction is recorded in002.h.
### 002.c — Compare and select → 001.c
On the same final24-case historical core suite, baseline23 passed/1 failed and selected24 passed. The baseline accepted trace maps omitting executed decisions; the continuation rejected them. Both snapshot variants matched the full-data outputs. This was an incremental comparison with prior skill exposure, not causal evidence of a skill-only effect. [Comparison and checks](../../artifacts/mas/merged-kline-family/comparison.md).
### 002.d — Test → 001.d
At the two-class correction checkpoint, **211 regression tests and32 focused cases passed**; strict mypy, Black and Ruff passed. Algorithm/adapter statement coverage was350/354 (98.87%). Cases include memo015’s worked examples,648 small-sequence oracle checks, initialization paths, source/trace validation, immutability, conversion and plotting. [Detailed checks](../../artifacts/mas/merged-kline-two-class/checks/).

The complete sample has10,060 raw bars and6,200 merged intervals. All5 policies give the same full-data result because its startup is unambiguous; synthetic cases exercise actual UNSET/BOTH outcomes. Two-class differential tests compared2,580 sequence-policy cases and all5 full-input paths, including complete trace evidence and6,200 explanations. This is tested equivalence, not a general correctness proof. Memo013’s later raw-family checks have their own test totals.
### 002.e — Handoff and remaining scope
The two-class implementation and both source entry points are usable with explicit configuration. Every result remains `unconfirmed` with `confirmed_at=None`; EOF completion does not imply confirmation. BOTH retains both paths and reports warning evaluation as `not_evaluated`. General DecisionStep, confirmation rules, warning scoring, later feature adapters and expanded per-key CSV columns remain deferred.
### 002.f — Plotly implementation and samples
`merged.plot(...)` delegates to [merged_kline_plot.py](../../src/chanlab/visualization/merged_kline_plot.py), using the existing optional plot extra. Worked-example and real-data PNGs were visually inspected; their byte-identical memo copies are embedded in003.f. Trace coordinates were checked against raw/merged values. Unlike memo013’s current consecutive-bar default, merged charts retain their calendar-axis contract. [Samples](../../artifacts/merged-kline/README.md).
### 002.g — ChanTable and DataFrame integration
[The table adapter](../../src/chanlab/data/merged_kline_table.py) implements memo009’s registration, retrieval and compact DataFrame view. Both raw and table inputs retain their exact source snapshot. Fixed mk_* columns project the first registered key; all keys retain authoritative records/config/rules/trace and source/result digests in versioned context. CSV export requires the context sidecar. DataFrame uses the optional dataframe extra; its attrs are not an interchange format.

Full10,060-row table/context roundtrip preserves6,200 records, rules, configuration and explanations, with unchanged raw values and original input hashes. The two-class refactor reads the prior format and reproduces its CSV/context bytes exactly. [Integration task](../../mas/tasks/20261109-memo026-table-integration.md); [persisted sample](../../artifacts/mas/merged-kline-family/integration/verification.json).
### 002.h — Two-class OOP correction
The current implementation follows memo009’s two-class boundary using the Computer Scientist skill.[5] Configuration, traces, temporary intervals and special outcomes are immutable data. Calculation/initialization/validation stays in private methods; public conversion/plot methods delegate internal adapters. No extra domain members, initialization default, confirmation rule or warning metric was added. Historical baseline/skill snapshots remain unchanged. [Task](../../mas/tasks/20261109-memo026-two-class-refactor.md); [differential and compatibility verification](../../artifacts/mas/merged-kline-two-class/verification.json).
## 003 — Implemented classes, members and methods
### 003.a — Class count and scope
**This memo implements two classes: `MergedKline` and `MergedKlineSeries`.** Both are defined in [merged_kline.py](../../src/chanlab/algo/merged_kline.py), following memo009.

| Class | Represents | Stored members | Main methods |
|---|---|---|---|
| `MergedKline` | One merged price interval. | Eight fields, listed in003.b. | Constructor and validate(). |
| `MergedKlineSeries` | Ordered merged records tied to the exact raw source. | Six fields, listed in003.c. | Constructor, calculation, validation, sequence access, ID lookup, explanation, table conversion, DataFrame export and plotting. |

This count is specific to memo026. Kline/KlineTSeries belong to memo013; ChanTable belongs to memo011. Configuration and trace/state/outcome payloads are read-only data, not additional classes. Public operations belong to the two classes; private methods handle inclusion processing, and adapters supply serialization/rendering details.
### 003.b — MergedKline
**Members — the data stored in each merged interval**

| Member | Declared type | Meaning |
|---|---|---|
| `id` | `int` | Nonnegative result-scoped integer ID; MK prefix is display-only. |
| `low` | `float` | Lower bound after inclusion processing. |
| `high` | `float` | Upper bound after inclusion processing. |
| `direction` | `Direction` | Alias for `"up"`, `"down"` or None while unresolved. |
| `source_start` | `int` | First member position in the exact raw source, inclusive; also display placement. |
| `source_stop` | `int` | Raw member end position, exclusive. |
| `status` | `str` | Currently only `"unconfirmed"` is accepted. |
| `confirmed_at` | `datetime \| None` | Currently must be None; no confirmation rule has been selected. |

All eight members are immutable. IDs and source positions are distinct. Raw members are recovered from `source_series[source_start:source_stop]`; a merged record stores no invented open/close/volume or independent display timestamp.

**Methods**

| Method | Normal use | Behavior |
|---|---|---|
| `__init__(id, low, high, direction, source_start, source_stop, status="unconfirmed", confirmed_at=None)` | `bar = MergedKline(...)` | Generated dataclass constructor: store fields and automatically validate. |
| `validate() -> None` | `bar.validate()` | Check nonnegative integer IDs/indices excluding bool, finite ordered bounds, nonempty range, direction and status/time contract. Owning series checks source upper bounds. |

Internal hook: `__post_init__()` calls validate(); private `_validate_integer()` supplies the integer check. Dataclass-generated equality/representation are standard Python behavior, separate from the domain interface.
### 003.c — MergedKlineSeries
**Members — the data stored in each result series**

| Member | Declared type | Meaning |
|---|---|---|
| `source_series` | `KlineTSeries` | Exact immutable raw object used for this calculation. |
| `klines` | `tuple[MergedKline, ...]` | Nonempty completed merged records in source order. |
| `config` | `Mapping[str, str]` | Immutable copy of explicit rule options; currently one initialization policy. |
| `rule_tree_ref` | `str` | Nonblank rule location/version supplied by the caller. |
| `trace` | `tuple[Mapping[str, Any], ...]` | Immutable rule/index/before/candidate/after evidence, including decisions with no saved output. |
| `trace_by_point` | `tuple[tuple[int, ...], ...]` | For each result position, a nonempty tuple of trace indices. Every executed event must be covered. |

The series stores six members. It references raw data and its owned provenance through `source_series`, rather than copying raw bars/context into new members. Configuration, trace and nested evidence are copied/frozen at construction. A complete series covers the full raw input continuously and has no inclusion between adjacent merged records, including equal boundaries. Nonadjacent inclusion is allowed.

**Methods**

| Method | Normal use | Behavior or result |
|---|---|---|
| `__init__(source_series, klines, config, rule_tree_ref, trace, trace_by_point)` | `merged = MergedKlineSeries(...)` | Store exact raw reference, snapshot immutable data and validate automatically. Normally use a factory below. |
| `derive_from(source_series, config, rule_tree_ref)` | `merged = MergedKlineSeries.derive_from(...)` | Class method: calculate from KlineTSeries or ChanTable. Normally returns MergedKlineSeries; unresolved UNSET/BOTH behavior is specified below. |
| `from_chan_table(table, series_key)` | `merged = MergedKlineSeries.from_chan_table(...)` | Class method: retrieve the exact registered result after validation, without recalculation. Missing key raises KeyError. |
| `validate() -> None` | `merged.validate()` | Check raw/records, unique IDs, full source partition, adjacent noninclusion, configuration and complete trace mapping. Structural validation does not replay every calculated price. |
| `__len__() -> int` | `len(merged)` | Number of merged records. |
| `__iter__()` | `for bar in merged` | Iterate in source order. |
| `__getitem__(key)` | `merged[index]` or `merged[start:stop:step]` | Integer → record; slice → tuple, possibly empty. Normal negative indices; no ID/source/trace renumbering. |
| `get_by_id(feature_id)` | `merged.get_by_id(12)` | Lookup result-scoped integer ID. Missing valid ID raises KeyError; invalid ID raises ValueError. |
| `explain(point_index) -> str` | `merged.explain(0)` | Explain a result position using its ID, source range, rule reference and linked evidence. Position is not a feature ID. |
| `to_chan_table(table, series_key)` | `view = merged.to_chan_table(base, "merged")` | Return new registered table view. Require exact same raw object; preserve existing view/registrations and reject conflicting key. |
| `to_dataframe()` | `frame = merged.to_dataframe()` | Return detached compact pandas DataFrame; one row per record and provenance/config/rule/result metadata in attrs. Requires dataframe extra. |
| `plot(*, start=None, stop=None, volume=True, title=None)` | `fig = merged.plot(...)` | Return Plotly Figure without automatic display/export. Requires plot extra. |

Class factories are called on MergedKlineSeries; instance methods operate on an existing result. `__getitem__` is one method with typed integer/slice overloads. Internal hook `__post_init__()` snapshots and validates construction data. Calculation/initialization/trace helpers are private methods; their inventory is in the Appendix.

**Arguments of derive_from() — call inputs, not additional members/classes**

| Argument | Input | Meaning |
|---|---|---|
| `source_series` | KlineTSeries or ChanTable | Use the raw object directly, or the table’s exact source_series. |
| `config` | `{"initialization": "UP"}` | Required explicit policy: UP, DOWN, OUTER, BOTH or UNSET. No default; unsupported keys/policies raise ValueError. |
| `rule_tree_ref` | nonblank string | Exact rule version/location used; examples use memo015’s SHA-256. |

The normal factory result is one completed MergedKlineSeries. Only an actual unresolved inclusion triggers special read-only data: UNSET returns `kind="pending"` with the unconsumed candidate; BOTH returns `kind="dual"`, `main` and `comparison` series plus unevaluated-warning metadata. These are plain mappings, not extra classes. The Appendix gives the data fields;003.e shows how to handle them.

**Arguments of plot() — call options, not stored members**

| Argument | Type | Default | Meaning |
|---|---|---|---|
| `start` | `int \| None` | None | Inclusive merged-record position; negative values count from the end. |
| `stop` | `int \| None` | None | Exclusive merged-record end. Both omitted selects all. |
| `volume` | `bool` | True | Include unchanged raw volume over the selected source extent. |
| `title` | `str \| None` | None | Custom chart title; otherwise raw symbol/period. |

The selected records are already calculated: slicing does not recompute initialization. Empty selections raise ValueError. Range marks sit at the first raw member’s timestamp; source extent remains separate. Unlike memo013’s raw default, the current merged plot preserves calendar spacing; it does not expose a show_gaps option. Both charts retain original UTC timestamps/OHLCV.
### 003.d — Object workflow and implementation boundary
Use objects throughout: load raw data or a table, calculate/retrieve merged results, then call conversion or plotting methods.

| Public operation | Owner | Implementation / result |
|---|---|---|
| Load raw bars and provenance | `KlineTSeries.read_csv(...)` | Memo013 factory returns one raw object owning context. |
| Load existing master rows/context | `ChanTable.read_csv(...)` | Existing table and its exact raw source; stored features are restored if supplied. |
| Calculate merged results | `MergedKlineSeries.derive_from(...)` | Private class methods implement memo015. |
| Build table from an existing raw object | `ChanTable.from_source_series(raw, context=raw.context)` | Retain raw identity; explicitly carry its provenance into the table. |
| Register/retrieve a result | `merged.to_chan_table(...)` / `MergedKlineSeries.from_chan_table(...)` | [Table adapter](../../src/chanlab/data/merged_kline_table.py) checks raw identity/key/context and derives MK columns. |
| Save table and registered features | `view.write_csv(path, context_path)` | Existing ChanTable writes row CSV plus versioned authoritative context. |
| Export compact rows | `merged.to_dataframe()` | Same adapter; detached DataFrame, no inverse importer. |
| Build a chart | `merged.plot(...)` | [Renderer](../../src/chanlab/visualization/merged_kline_plot.py) returns Figure. |

Raw-route provenance is owned by `raw.context`. When creating a table from raw, pass it explicitly as above; from_source_series does not copy that context by default. The existing-table route retains `table.context`. MergedKlineSeries has no extra context member; source provenance and table metadata stay with their owning objects.

In-memory retrieval returns the exact registered series; a disk reload creates new results sharing the newly loaded raw snapshot. Registration requires identity, not merely equal-valued bars. The same key cannot name a different result object. Multiple keys are retained; the first supplies the fixed mk_* columns, with other keys available through keyed memberships/markers and versioned context. Other feature-family columns remain NA.

MK membership covers `[source_start,source_stop)`; start/end markers are at source_start/source_stop−1; direction appears only at the start. CSV ID cells use JSON arrays, including `[]` for computed-empty markers; unresolved/inapplicable direction is NA. Raw columns are unchanged. These columns alone cannot recover bounds/config/rules/trace, so registered-feature writes require a separate context destination. Data/context paths must differ. DataFrame attrs are not retained by ordinary DataFrame CSV export.
### 003.e — Usage examples
Run from the repository root with `PYTHONPATH=src .venv/bin/python`. Optional export/plot support: `uv sync --extra dataframe --extra plot`.

**From the Kline family — one raw object owns bars and provenance**
```python
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory

from chanlab.algo.kline import KlineTSeries
from chanlab.algo.chan_table import ChanTable
from chanlab.algo.merged_kline import MergedKline, MergedKlineSeries

folder = Path("samples/chan_table")
rows_path = next(folder.glob("*chan_table*.csv"))
context_path = next(folder.glob("*context*.csv"))
raw = KlineTSeries.read_csv(rows_path, context_path)
assert len(raw) == 10060 and len(raw.context) == 9
rule_path = Path("docs/memo/memoWX_015_Chan_mergedkline.md")
rule_ref = "memo015:sha256:" + sha256(rule_path.read_bytes()).hexdigest()
config = {"initialization": "UP"}
merged = MergedKlineSeries.derive_from(raw, config, rule_ref)
assert isinstance(merged, MergedKlineSeries)
assert merged.source_series is raw and len(merged) == 6200
bar = merged.get_by_id(merged[0].id)
assert isinstance(bar, MergedKline)
members = raw[bar.source_start:bar.source_stop]
assert members
print(merged.explain(0))
base = ChanTable.from_source_series(raw, context=raw.context)
view = merged.to_chan_table(base, "merged")
assert MergedKlineSeries.from_chan_table(view, "merged") is merged
assert all(view.context[key] == value for key, value in raw.context.items())
```

**From an existing ChanTable — calculate, write and read back**
```python
base = ChanTable.read_csv(rows_path, context_path)
merged = MergedKlineSeries.derive_from(base, config, rule_ref)
assert isinstance(merged, MergedKlineSeries)
assert merged.source_series is base.source_series
view = merged.to_chan_table(base, "merged")
with TemporaryDirectory() as directory:
    output = Path(directory)
    view.write_csv(output / "chan.csv", output / "context.csv")
    loaded = ChanTable.read_csv(output / "chan.csv", output / "context.csv")
    restored = MergedKlineSeries.from_chan_table(loaded, "merged")
    assert restored.klines == merged.klines
    assert restored.source_series is loaded.source_series
frame = merged.to_dataframe()
assert len(frame) == 6200
```

**Handle any explicit initialization policy**
```python
outcome = MergedKlineSeries.derive_from(raw, {"initialization": "BOTH"}, rule_ref)
if isinstance(outcome, MergedKlineSeries):
    main = outcome
elif outcome["kind"] == "dual":
    main = outcome["main"]
    comparison = outcome["comparison"]
else:
    raise RuntimeError(f"Initialization required at raw[{outcome['raw_index']}]")
assert isinstance(main, MergedKlineSeries)
```

**Plotting**
```python
fig = merged.plot(start=-40, volume=True, title="Last 40 merged intervals")
assert fig.layout.xaxis.type == "date"
# Optional: fig.show() or fig.write_html(path, include_plotlyjs=True)
```
The Figure belongs to the caller. The plot() example uses calendar spacing; the additional gap-free panel/overlay pictures use the sample generators linked below. Merged intervals represent low/high only; original candles retain their OHLC.

| Sample | Interactive HTML | PNG preview |
|---|---|---|
| Last40 raw bars, gap-free overlay | [Open](../../artifacts/merged-kline/cc-last40-overlay-gapfree.html) | [Preview](../../artifacts/merged-kline/cc-last40-overlay-gapfree.png) |
| Last40 raw bars, gap-free raw/merged panels | [Open](../../artifacts/merged-kline/cc-last40-raw-and-merged-gapfree.html) | [Preview](../../artifacts/merged-kline/cc-last40-raw-and-merged-gapfree.png) |
| Memo015 worked example | [Open](../../artifacts/merged-kline/worked-example.html) | [Preview](../../artifacts/merged-kline/worked-example.png) |
| Last40 merged intervals | [Open](../../artifacts/merged-kline/cc-last40-merged.html) | [Preview](../../artifacts/merged-kline/cc-last40-merged.png) |

### 003.f — Chart pictures
**Gap-free comparison — 40 raw bars and their26 merged intervals.** The top panel shows the last40 original candles; the lower panel shows the full-input merge result on the same consecutive-bar axis. Blocks span their original members and show merged low/high only; they do not invent merged open/close values. Blue/orange means upward/downward merge direction. Calendar gaps are hidden, original UTC labels remain, and no error-bar-style marks are used.

![Last40 raw Klines and26 merged intervals on a shared gap-free axis](memoWX_026_MergedKlineFamily/cc-last40-raw-and-merged-gapfree.png)

This additional picture uses the [sample generator](../../artifacts/mas/merged-kline-gapfree/generate.py); it does not change the current plot() API. The merge is calculated on the entire10,060-bar input before selecting the40-bar viewport. [Interactive chart](../../artifacts/merged-kline/cc-last40-raw-and-merged-gapfree.html); [value/source verification](../../artifacts/mas/merged-kline-gapfree/verification.json).

**Gap-free overlay — the same40 raw bars and26 merged intervals.** Original red/green candles are in the foreground. Transparent blue/orange boxes show upward/downward merged low–high bounds; each box spans its original member bars. The light fill keeps candle bodies and wicks visible. A raw wick can extend beyond the box because directional inclusion processing adjusts merged bounds; the box is not the raw group’s outer envelope.

![Gap-free original Klines overlaid on transparent merged-range boxes](memoWX_026_MergedKlineFamily/cc-last40-overlay-gapfree.png)

The [interactive overlay](../../artifacts/merged-kline/cc-last40-overlay-gapfree.html) allows merged direction groups to be hidden/shown through the legend. Both overlay and two-panel comparison use identical full-data calculation and viewport. [Generator](../../artifacts/mas/merged-kline-gapfree/generate_overlay.py); [source/geometry verification](../../artifacts/mas/merged-kline-gapfree/overlay-verification.json). The existing plot() API is unchanged.

**Worked example.** Ten synthetic raw bars become three merged intervals. Gray/blue/orange marks show unresolved/up/down direction at the first raw-member timestamp; source ranges retain all ten bars.

![Memo015 ten-bar worked example with three merged intervals](memoWX_026_MergedKlineFamily/worked-example.png)

**Calendar comparison — earlier sample.** Last40 already-calculated merged intervals over original candles and volume. Calendar gaps remain visible; no raw values or timestamps were changed.

![Last40 merged intervals over original raw candles and volume](memoWX_026_MergedKlineFamily/cc-last40-merged.png)

## Appendix — Contracts and reproduction
1. **Initialization:** explicit configuration mapping; no project default. BOTH/UNSET return tagged read-only data only if ambiguous inclusion is encountered.
2. **Confirmation:** only unconfirmed/None supported. EOF completion and first-member display placement are not confirmation evidence.
3. **Trace:** read-only mappings retain rule and before/candidate/after evidence. Nested work data contains raw reference, low/high, direction and source_start/source_stop. General DecisionStep remains deferred; this is not a cross-feature schema.
4. **Warning:** BOTH retains both full paths and original request; source-aware difference scoring/threshold/delivery remain unimplemented and explicitly unevaluated.
5. **Adapters:** implemented in002.g/003.c–003.e. Fixed41-column master schema remains; authoritative feature data uses the versioned context entry. Other concept adapters and expanded per-key CSV columns remain future work.
6. **Plotting:** existing optional Plotly extra; UTC/session gaps retained; raw volume only. PNG export uses temporary Kaleido/local Chrome tooling, not a new runtime requirement.
7. **Reproduction:** [current refactor verification](../../artifacts/mas/merged-kline-two-class/verify.py) compares old/new behavior and prior persisted-context compatibility. [Original verify.py](../../artifacts/mas/merged-kline-family/verify.py) reruns frozen historical comparisons and current chart outputs. Run with `PYTHONPATH=src` in an environment containing pytest/Plotly; PNG export additionally needs Kaleido/Chrome. Tooling/check commands and limitations are in [the task](../../mas/tasks/20261109-memo026-execution.md).

### Internal class methods and factory data
These are implementation details, separated from the caller-facing class reference in003.

**Automatic hook and private implementation methods**

| Method | Responsibility |
|---|---|
| `__post_init__()` | Freeze input data and call validate(). |
| `_validate_config(config)` | Require explicit initialization mapping; reject unsupported keys/policies. |
| `_freeze_data(value)` | Recursively detach/freeze configuration and evidence containers. |
| `_work(...)`, `_change(work, **changes)` | Construct or replace validated private interval data. No work class. |
| `_work_from_raw(raw, i, direction=None)` | Initialize one private work interval from a raw bar. |
| `_has_inclusion(a, b)` | Symmetric inclusive containment, including equality. |
| `_direction_between(a, b)` | Strict up/down for a nonincluded chronological pair. |
| `_check_pair(current, candidate)` | Same raw snapshot, continuous ranges and one included raw candidate. |
| `_merge_included(current, candidate)` | Known direction: max/max upward or min/min downward. |
| `_merge_outer_boundary(current, candidate)` | Explicit unresolved OUTER envelope, retaining None. |
| `_validate_step(step, raw)` | Validate decision fields, supported rule/index and evidence source/ranges. |
| `_validate_result(raw, result)` | Complete source coverage, record/ID checks and adjacent noninclusion. |
| `_advance(...)` | Own sequential processing, initialization, independent dual paths, ID assignment, saving and EOF. |

The six helpers from memo015 are now private methods on MergedKlineSeries. The main loop owns consumption counters, record IDs, saving and EOF; each returned work mapping is immutable. `_validate_integer` belongs to MergedKline and is reused for indices.

| Special outcome | Read-only fields |
|---|---|
| UNSET at ambiguous inclusion | `kind="pending"`, `source_series`, `config`, `rule_tree_ref`, `saved`, `current`, `candidate`, `raw_index`, `trace`. The candidate is unconsumed; no completed-series/resume API is implied. |
| BOTH at ambiguous inclusion | `kind="dual"`, `main`, `comparison`, `requested_config`, `warning_evaluation="not_evaluated"`. Each path owns independent work/result state and references the same raw object. |

Trace entries contain `rule`, `raw_index`, `before`, `candidate`, `after`. Nested interval data contains `raw`, `low`, `high`, `direction`, `source_start`, `source_stop`; candidate is None for initialization/EOF. Normal complete factory results remain MergedKlineSeries objects.

## References
1. [Memo009 — Design pattern for Chan features](memoWX_009_designPatternForChanFeatures.md), sections001.b–001.e,002.d–002.e and002.u.
2. [Memo015 — Chan_mergedkline](memoWX_015_Chan_mergedkline.md), sections001 and002.a–002.d.
3. [Memo013 — Kline family implementation](memoWX_013_klineFamily.md), sections001–003 and Plotly Appendix; [core execution task](../../mas/tasks/20261108-memo013-execution.md) and [comparison](../../artifacts/mas/kline-family/comparison.md).
4. [Memo012 — Python Pro skill](memoWX_012_Skill_python_pro.md).
5. [Computer Scientist skill](../../mas/skills/computer-scientist/SKILL.md), installed K-Dense1.0.0; applied directly by Codex for the two-class abstraction/invariant review.
